<?php
$server = "localhost";
 $username = "root";
 $password= "";
 $database = "droame";
/* Attempt to connect to MySQL database */
$conn = mysqli_connect($server,$username,$password,$database);
?>