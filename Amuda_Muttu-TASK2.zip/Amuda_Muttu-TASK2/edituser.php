<?php
include('adminnav.php');
include('Configuration.php');
//include('session.php');
$customer_id =  $_GET['customer_id'];
$result1 = mysqli_query($conn, " SELECT * FROM customer where customer_id ='$customer_id';");
$row = mysqli_fetch_array($result1);


?>

<div class="container1 m-5">
    <div class="title">Edit  User</div>
    <div class="content">
      <form method="post" action="updateuser.php" enctype="multipart/form-data" >
        <div class="user-details">
            <div class="input-box">
             <i class="fa fa-user icon"></i>
             <input  type="hidden" placeholder="id" name="customer_id" id="name" value="<?php echo $row['customer_id']; ?>">
             <input class="input-field" type="text" placeholder="Customer_Name" name="customer_name" id="customer_name" value="<?php echo $row['customer_name']; ?>">
             <span class="text-danger font-weight-bold" id="nameError"></span>
            </div>
          <div class="input-box">
            <i class="fa fa-envelope icon"></i>
    <input class="input-field" type="text" placeholder="Email" name="email" id="email" value="<?php echo $row['email']; ?>">
    <span class="text-danger font-weight-bold" id="emailError"></span>
  </div>
          <div class="input-box">
            <i class="fa fa-mobile icon"></i>
            <input class="input-field" type="text" placeholder="Age" name="age" id="age" value="<?php echo $row['age']; ?>">
            <span class="text-danger font-weight-bold" id="mobileError"></span>
          </div>

          <div class="input-box">
            <i class="fa fa-mobile icon"></i>
            <input class="input-field" type="text" placeholder="Mobile Number" name="mobile" id="mobile" value="<?php echo $row['mobile']; ?>">
            <span class="text-danger font-weight-bold" id="mobileError"></span>
          </div>
  <div class="input-box">
            <i class="fa fa-address-card icon"></i>
    <input class="input-field" type="text" placeholder="Address" name="address" value="<?php echo $row['address']; ?>">
  </div>
         
         
        
    </div>

        <div class="button">
          <input type="submit" name ="updateuser" value="Update User">
        </div>
      </form>
    </div>
  </div>
                                                        </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/app.js"></script>


   