<?php
include('Configuration.php');
include('adminnav.php');


?>

<script>
    function ConfirmDelete()
    {
      var x = confirm("Are you sure you want to delete?");
      if (x)
          return true;
      else
        return false;
    }
	

    function ConfirmEdit()
    {
      var x = confirm("Are you sure you want to Edit?");
      if (x)
          return true;
      else
        return false;
    }
	
	
</script> 

<style>
	.e1{
		width:100px;
		height:100px;
		border-radius:10px;
	}
	</style>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	<h2><a href="adduser.php">Add User</a></h2><style>
	.e1{
		width:150px;
		height:150px;
		border-radius:10px;
	}
	</style>
<div class="table-responsive container-fluid " style=" border:2px solid black;padding:2% align:center; ">
<?php

	 $result1 = mysqli_query($conn, " SELECT * FROM customer ");
	 echo "<table class='table table-striped table-bordered table-hover table-condensed bg-light' id='tblCustomers'>
	 			<tr><th>Customer_ID</th><th>Customer_Name</th><th>Email</th><th>Mobile_Number</th><th>Address</th><th>Age</th><th>Gneder</th><th>Edit || Delete</th></tr>";

    while ($row = mysqli_fetch_array($result1)) {
		echo "<tr><td><b>".$row['customer_id']."</b></td>";
			echo "<td>".$row['customer_name']."</td>";
			echo "<td>".$row['email']."</td>";
			echo "<td>".$row['mobile']."</td>";
		
			echo "<td>".$row['address']."</td>"; 
			echo "<td>".$row['age']."</td>";
			
			echo "<td>".$row['gender']."</td>";
			
			
			
			echo "<td><a href='edituser.php?customer_id=$row[customer_id]'  Onclick='return ConfirmEdit();'><i class='fa fa-edit'>&nbsp;</i></a> || "; 
			echo "<a href='deleteuser.php?customer_id=$row[customer_id]' Onclick='return ConfirmDelete();'><i class='fa fa-remove text-danger'>&nbsp;</i></a></td></tr>"; 
    }
	echo "</table>";
?>
</div>
