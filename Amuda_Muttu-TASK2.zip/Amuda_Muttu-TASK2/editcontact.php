<?php 
include('Configuration.php');
include('adminnav.php');
// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

if ($conn) {
    $booking_id = (int)$_GET['booking_id'];
    $stmt = mysqli_prepare($conn, "SELECT * FROM bookings WHERE booking_id = ?");
    mysqli_stmt_bind_param($stmt, "i", $booking_id);
    mysqli_stmt_execute($stmt);
    $result1 = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_array($result1);
}

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
    background-image: url("B2.jpg");
    background-repeat: no-repeat;
    background-size: cover;
font-family: Arial, Helvetica, sans-serif;
}

* {box-sizing: border-box;}
.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 80%;
  margin-bottom: 15px;
  border: 1.5px solid #ff4d29;
  border-bottom-width: 3px;
  transition: all 0.3s ease;
}

.icon {
  padding: 10px;
  background: #ff4d29;
  color: white;
  min-width: 50px;
  text-align: center;
}

.input-field {
  width: 200%;
}

.input-field:focus {
  border: 2px solid dodgerblue;
}

/* Set a style for the submit button */
.btn {
  background-color: #ff4d29;
  color: white;
  padding: 15px 20px;
  border: none;
  cursor: pointer;
  width: 80%;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
}
.content {
    max-height: 300px;
    overflow-y: scroll;
  }
</style>
</head>
<body>
<form action="updatecontact.php" method="post" style="max-width:500px;margin:auto" enctype="multipart/form-data">
  <h2>Person Information</h2>


  <div class="input-container">
    <i class="fa fa fa-map-marker icon"></i>
    <input class="input-field" type="hidden" placeholder="Username" name="booking_id" value="<?php echo $row['booking_id'];?>">
    <input class="input-field" type="text" placeholder="Location_id" name="location_id" value="<?php echo $row['location_id'];?>">
  </div>

<div class="input-container">
    <i class="fa fa-mobile icon"></i>
    <input class="input-field" type="number" placeholder="drone_shot_id" name="drone_shot_id" value="<?php echo $row['drone_shot_id'];?>">
  </div>

<div class="input-container">
    <i class="fa fa-clock-o icon"></i>
    <input class="input-field" type="number" placeholder="Created_time" name="Created_time" value="<?php echo $row['Created_time'];?>">
  </div>

  <div class="input-container">
    <i class="fa fa-map icon"></i>
    <input class="input-field" type="text" placeholder="Location" name="Location" value="<?php echo $row['Location'];?>">
  </div>
  

<div class="input-container">
    <i class="fa fa-address-card icon"></i>
    <input class="input-field" type="text" placeholder="date" name="date" value="<?php echo $row['date'];?>">
  </div>


  <button type="submit" class="btn" name="updatecontact" value="Update Bookings">Update Bookings</button>
</form>

