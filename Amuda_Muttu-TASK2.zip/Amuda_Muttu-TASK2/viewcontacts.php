<?php

include('Configuration.php');
include('adminnav.php');


?>
<style>
	.e1{
		width:100px;
		height:100px;
		border-radius:10px;
	}
	</style>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	<h2><a href="addcontact.php">Add Bookings</a></h2><style>
	.e1{
		width:100px;
		height:100px;
		border-radius:10px;
	}
	</style>
<div class="table-responsive container-fluid " style=" border:2px solid black;padding:2%;">
<?php
	 $result1 = mysqli_query($conn, " SELECT * FROM bookings");
	 echo "<table class='table table-striped table-bordered table-hover table-condensed bg-light' id='tblCustomers'>
	 			<tr><th>Booking_ID</th><th>Location_ID</th><th>Drone_Shot_ID</th><th>Created_Time</th><th>Location</th><th>Date</th><th>Edit || Delete</th></tr>";

    while ($row = mysqli_fetch_array($result1)) {
			echo "<td>".$row['booking_id']."</td>";
			echo "<td>".$row['location_id']."</td>";
			echo "<td>".$row['drone_shot_id']."</td>";
			echo "<td>".$row['Created_time']."</td>"; 
			echo "<td>".$row['Location']."</td>";
			echo "<td>".$row['date']."</td>";
			echo "<td><a href='editcontact.php?booking_id=$row[booking_id]'><i class='fa fa-edit'>&nbsp;</i></a> || "; 
			echo "<a href='deletecontact.php?booking_id=$row[booking_id]'><i class='fa fa-remove text-danger'>&nbsp;</i></a></td></tr>"; 
    }
	echo "</table>";
?>
</div>
