<?php
// include database connection file
include_once("Configuration.php");

// Get id from URL to delete that user
$booking_id = $_GET['booking_id'];

// Delete user row from table based on given id
$result = mysqli_query($conn, "DELETE FROM bookings WHERE booking_id='$booking_id'");

// After delete redirect to Home, so that latest user list will be displayed.
header("Location:viewcontacts.php");
?>

