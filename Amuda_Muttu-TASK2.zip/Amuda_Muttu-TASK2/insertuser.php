<?php

// Include config file
require_once "Configuration.php";
 
// Define variables and initialize with empty values

 
// Processing form data when form is submitted
if($conn)
{
    if(isset($_POST['adduser']))
    {
      $customer_id=$_POST['customer_id'];
        $customer_name=$_POST['customer_name'];
        $email=$_POST['email'];
        
        $age=$_POST['age'];
        $mobile=$_POST['mobile'];
        $address=$_POST['address'];
        
        $gender=$_POST['gender'];
       
       
		$uploadOk = 1;
              // image file directory
             
              
              
            if($uploadOk ==1){

              $query= "insert into customer(customer_id, customer_name,email,age,mobile,address,gender) 
              values('$customer_id' ,'$customer_name','$email','$age',$mobile,'$address','$gender');";
            
              if(mysqli_query($conn,$query)){

                
                     echo "<script>alert('Added Successfully ');</script>"; 
                     echo "<script>window.location.href='viewusers.php';</script>"; 
                }
            }
        
    }
}

?>