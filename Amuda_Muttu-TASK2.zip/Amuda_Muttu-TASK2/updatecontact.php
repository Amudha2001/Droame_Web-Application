<?php 
include('Configuration.php');
include('adminnav.php');
// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

if($conn)
{
        if(isset($_POST['updatecontact']))
        {
            $booking_id=$_POST['booking_id'];
              $location_id=$_POST['location_id'];
              $drone_shot_id=$_POST['drone_shot_id'];
              $Created_time=$_POST['Created_time'];
              $Location=$_POST['Location'];
             
              $date=$_POST['date'];
              
              
          
$query= "UPDATE bookings SET location_id='$location_id', drone_shot_id='$drone_shot_id', Created_time='$Created_time', Location='$Location', date='$date' WHERE booking_id='$booking_id'";
         
            
              if(mysqli_query($conn,$query)){
                     echo "<script>alert('Contact  Details Updated successfully');</script>"; 
                    echo "<script>window.location.href='viewcontacts.php';</script>"; 
                }else{
                     echo "<script>alert('Contact  Details Updating Failed ');</script>"; 
                     echo "<script>window.location.href='viewcontacts.php';</script>";
                }
    }
}

?>